package com.example.examcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamCrudApplication.class, args);
	}

}
